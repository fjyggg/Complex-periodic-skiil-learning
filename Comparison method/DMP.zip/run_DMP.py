import numpy as np
from DMP import DMP
import matplotlib.pyplot as plt
np.random.seed(5)


def compute_Sea(x_set1, x_set2):
    def compute_area(A, B, C, D):
        comp1 = np.linalg.det(np.vstack((A, B)).T)
        comp2 = np.linalg.det(np.vstack((B, C)).T)
        comp3 = np.linalg.det(np.vstack((C, D)).T)
        comp4 = np.linalg.det(np.vstack((D, A)).T)
        S = np.abs((comp1 + comp2 + comp3 + comp4) / 2)
        return S

    S = 0.0
    size = np.shape(x_set1)[0]
    for k in range(size - 1):
        area = compute_area(x_set1[k, :], x_set1[k + 1, :], x_set2[k + 1, :], x_set2[k, :])
        S = S + area
    return S


type = '2D_unregular'
x_set = np.loadtxt('data_set/filter_set/filtered_x_' + type + '.txt')
set_size = np.shape(x_set)[0]
t_set = 0.02 * np.arange(set_size)

T_length = None
tau = None
Period = None
step_T = 0.02
if type == '2D_circle':
    T_length = 313
elif type == '2D_rectangle':
    T_length = 378
elif type == '2D_star':
    T_length = 770
else:
    T_length = 1324 - 890
Period = T_length * step_T
dphi = 2 * np.pi / Period
tau = 1 / dphi
test_T_set = np.arange(0.0, 2 * Period, 0.02)
test_phi_set = test_T_set * (1 / tau)

dmp1 = DMP(x_set=x_set[:, 0], tau=tau, N=20, r=1.0)
savepath1 = 'parameters/DMP1_parameters_' + type + '.txt'
# omega1 = dmp1.train(savepath=savepath1)
omega1 = np.loadtxt(savepath1)

dmp2 = DMP(x_set=x_set[:, 1], tau=tau, N=20, r=1.0)
savepath2 = 'parameters/DMP2_parameters_' + type + '.txt'
# omega2 = dmp2.train(savepath=savepath2)
omega2 = np.loadtxt(savepath2)

off_x = np.random.normal(0.0, 5 * 1e-2, 2)
x = x_set[0, :]  # + off_x
dx = np.zeros(2)
Max_steps = int(Period / step_T)
k = 60.0
d = 2 * np.sqrt(k)
x_tra = [x]
dx_tra = [dx]
for i in range(Max_steps):
    time = i * step_T
    phi = time * (1 / tau)
    g1 = dmp1.f(phi, omega1)
    g2 = dmp2.f(phi, omega2)
    g = np.array([g1, g2])

    if 1.0 <= time <= 0.1:
        dx = 0.0
        ddx = 0.0
        x = x
    else:
        ddx = -d * dx - k * (x - g)
        x = x + dx * step_T + 0.5 * ddx * step_T**2
        dx = dx + ddx * step_T
    x_tra.append(x)
    dx_tra.append(dx)

x_tra = np.array(x_tra)
dx_tra = np.array(dx_tra)
S = compute_Sea(x_set[0:T_length], x_tra)
print(S)
plt.figure(figsize=(9, 6), dpi=100)
plt.subplots_adjust(left=0.12, right=0.99, wspace=0.15, hspace=0.2, bottom=0.1, top=0.99)
plt.plot(x_tra[:, 0], x_tra[:, 1], c='blue')
plt.plot(x_set[:, 0], x_set[:, 1], c='red', ls='--')
plt.scatter(x_set[0, 0], x_set[0, 1], s=50, marker='o', color='black')

plt.show()
'''
T = 10.0
Max_steps = int(T / Period)
for i in range(Max_steps):
'''

